import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import org.json.*;

public class SimpleGUI extends JFrame {
    private JButton queryButton;
    private JTextField ipInput;
    private JTable resultTable;
    private DefaultTableModel tableModel;
    private JButton settingsButton;
    private static String currentToken = "2c2adc6010af61b1524ffdad54edfcca"; // 默认token
    
    public SimpleGUI() {
        // 设置窗口标题
        super("IP查询工具");
        
        // 设置窗口大小
        setSize(800, 400);
        
        // 设置窗口关闭操作
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // 创建主面板
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        
        // 创建输入面板
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());
        
        // 创建输入组件
        ipInput = new JTextField(15);
        queryButton = new JButton("查询IP");
        settingsButton = new JButton("设置");
        
        inputPanel.add(new JLabel("IP地址："));
        inputPanel.add(ipInput);
        inputPanel.add(queryButton);
        inputPanel.add(settingsButton);
        
        // 添加设置按钮点击事件
        settingsButton.addActionListener(e -> showSettingsDialog());
        
        // 创建表格
        String[] columnNames = {"IP地址", "归属地", "运营商", "邮政编码", "网络类型"};
        tableModel = new DefaultTableModel(columnNames, 1);
        resultTable = new JTable(tableModel);
        resultTable.setRowHeight(30);
        resultTable.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        
        // 设置表格单元格渲染器
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBackground(Color.WHITE);
                setFont(new Font("微软雅黑", Font.PLAIN, 12));
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 1, Color.LIGHT_GRAY),
                    BorderFactory.createEmptyBorder(0, 5, 0, 5)
                ));
                setHorizontalAlignment(SwingConstants.CENTER);
                return c;
            }
        };
        
        // 设置表格头部样式
        JTableHeader header = resultTable.getTableHeader();
        header.setFont(new Font("微软雅黑", Font.BOLD, 12));
        header.setBackground(new Color(230, 230, 230));
        header.setForeground(Color.BLACK);
        
        // 添加自定义的表头渲染器
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(SwingConstants.CENTER);  // 设置居中对齐
                setBackground(new Color(230, 230, 230));
                setFont(new Font("微软雅黑", Font.BOLD, 12));
                setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 1, Color.LIGHT_GRAY),
                    BorderFactory.createEmptyBorder(5, 0, 5, 0)
                ));
                return c;
            }
        };
        
        // 应用表头渲染器到所有列
        for (int i = 0; i < resultTable.getColumnCount(); i++) {
            resultTable.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
        
        // 应用单元格渲染器到所有列
        for (int i = 0; i < resultTable.getColumnCount(); i++) {
            resultTable.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }
        
        // 禁止表格编辑
        resultTable.setEnabled(false);
        
        // 创建带边框的滚动面板
        JScrollPane scrollPane = new JScrollPane(resultTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        // 添加按钮点击事件
        queryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String ip = ipInput.getText().trim();
                if (ip.isEmpty()) {
                    showError("请输入IP地址");
                    return;
                }
                
                // 在新线程中执行查询
                new Thread(() -> {
                    try {
                        String result = QueryHelper.queryIP(ip, currentToken);
                        if (result != null) {
                            updateTable(result);
                        } else {
                            showError("查询失败，请检查网络连接或IP地址是否正确");
                        }
                    } catch (Exception ex) {
                        showError("发生错误：" + ex.getMessage());
                    }
                }).start();
            }
        });
        
        // 将组件添加到主面板
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // 设置面板边距
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // 将主面板添加到窗口
        add(mainPanel);
        
        // 设置窗口居中显示
        setLocationRelativeTo(null);
        
        // 设置列宽
        for (int i = 0; i < resultTable.getColumnCount(); i++) {
            TableColumn column = resultTable.getColumnModel().getColumn(i);
            switch (i) {
                case 0: // IP地址列
                    column.setPreferredWidth(120);
                    break;
                case 1: // 归属地列
                    column.setPreferredWidth(250);
                    break;
                case 2: // 运营��列
                    column.setPreferredWidth(150);
                    break;
                case 3: // 邮政编码列
                    column.setPreferredWidth(100);
                    break;
                case 4: // 网络类型列
                    column.setPreferredWidth(100);
                    break;
            }
        }
    }
    
    private void showError(String message) {
        SwingUtilities.invokeLater(() -> {
            // 清空所有单元格
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                tableModel.setValueAt("", 0, i);
            }
            // 在归属地列显示错误信息，这样更醒目
            tableModel.setValueAt("错误", 0, 0);
            tableModel.setValueAt(message, 0, 1);
        });
    }
    
    private void updateTable(String jsonStr) {
        try {
            org.json.JSONObject json = new org.json.JSONObject(jsonStr);
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    // 清空现有数据
                    for (int i = 0; i < tableModel.getColumnCount(); i++) {
                        tableModel.setValueAt("", 0, i);
                    }
                    
                    if (json.has("ret") && json.getString("ret").equals("ok")) {
                        org.json.JSONArray dataArray = json.getJSONArray("data");
                        if (dataArray.length() > 0) {
                            // 设置IP地址
                            tableModel.setValueAt(json.getString("ip"), 0, 0);
                            
                            // 合并地理位置信息
                            StringBuilder location = new StringBuilder();
                            for (int i = 0; i < Math.min(4, dataArray.length()); i++) {
                                String value = dataArray.getString(i);
                                if (!value.isEmpty() && !value.equals("null")) {
                                    if (location.length() > 0) {
                                        location.append(" ");
                                    }
                                    location.append(value);
                                }
                            }
                            tableModel.setValueAt(location.toString(), 0, 1);
                            
                            // 设置运营商
                            if (dataArray.length() > 4) {
                                tableModel.setValueAt(dataArray.getString(4), 0, 2);
                            }
                            
                            // 设置邮政编码和网络类型
                            if (dataArray.length() > 5) {
                                tableModel.setValueAt(dataArray.getString(5), 0, 3); // 邮政编码
                            }
                            if (dataArray.length() > 7) {
                                tableModel.setValueAt(dataArray.getString(7), 0, 4); // 网络类型
                            }
                        } else {
                            showError("未找到地理位置信息");
                        }
                    } else {
                        showError("API返回错误：" + json.optString("msg", "未知错误"));
                    }
                }
            });
        } catch (Exception e) {
            showError("解析结果失败：" + e.getMessage());
        }
    }
    
    private void showSettingsDialog() {
        JDialog dialog = new JDialog(this, "设置", true);
        dialog.setLayout(new BorderLayout(10, 10));
        
        // 主面板
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Token标签和输入框
        JLabel tokenLabel = new JLabel("IP138 Token:");
        JTextField tokenField = new JTextField(currentToken);
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        mainPanel.add(tokenLabel, gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        mainPanel.add(tokenField, gbc);
        
        // 状态标签
        JLabel statusLabel = new JLabel(" ");
        statusLabel.setForeground(Color.BLACK);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        mainPanel.add(statusLabel, gbc);
        
        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        
        JButton testButton = new JButton("测试Token");
        JButton saveButton = new JButton("保存");
        JButton cancelButton = new JButton("取消");
        
        // 初始状态下禁用保存按钮
        saveButton.setEnabled(false);
        
        // 测试按钮事件
        testButton.addActionListener(e -> {
            String testToken = tokenField.getText().trim();
            if (testToken.isEmpty()) {
                statusLabel.setText("Token不能为空");
                statusLabel.setForeground(Color.RED);
                return;
            }
            
            testButton.setEnabled(false);
            saveButton.setEnabled(false);
            statusLabel.setText("正在测试...");
            statusLabel.setForeground(Color.BLACK);
            
            new Thread(() -> {
                try {
                    String result = QueryHelper.queryIP("8.8.8.8", testToken);
                    if (result != null && result.contains("\"ret\":\"ok\"")) {
                        SwingUtilities.invokeLater(() -> {
                            statusLabel.setText("Token��效");
                            statusLabel.setForeground(new Color(0, 150, 0));
                            saveButton.setEnabled(true);
                        });
                    } else {
                        SwingUtilities.invokeLater(() -> {
                            statusLabel.setText("Token无效");
                            statusLabel.setForeground(Color.RED);
                            saveButton.setEnabled(false);
                        });
                    }
                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> {
                        statusLabel.setText("测试失败: " + ex.getMessage());
                        statusLabel.setForeground(Color.RED);
                        saveButton.setEnabled(false);
                    });
                } finally {
                    SwingUtilities.invokeLater(() -> testButton.setEnabled(true));
                }
            }).start();
        });
        
        // 保存按钮事件
        saveButton.addActionListener(e -> {
            String newToken = tokenField.getText().trim();
            if (!newToken.isEmpty()) {
                currentToken = newToken;
                dialog.dispose();
            }
        });
        
        // 取消按钮事件
        cancelButton.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(testButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // 添加组件到对话框
        dialog.add(mainPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // 设置对话框属性
        dialog.setSize(450, 150);
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        // 显示对话框
        dialog.setVisible(true);
    }
    
    // QueryHelper 内部类
    private static class QueryHelper {
        private static String DATATYPE = "json";
        
        public static String get(String urlString, String token) {
            try {
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(5 * 1000);
                conn.setReadTimeout(5 * 1000);
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("token", token);
                
                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    StringBuilder builder = new StringBuilder();
                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), "utf-8"));
                    for (String s = br.readLine(); s != null; s = br.readLine()) {
                        builder.append(s).append("\n");
                    }
                    br.close();
                    return builder.toString();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        
        public static String queryIP(String ip, String token) {
            String url = "https://api.ip138.com/ipdata/?ip=" + ip + "&datatype=" + DATATYPE;
            return get(url, token);
        }
    }
    
    public static void main(String[] args) {
        // 在事件调度线程中运行GUI
        SwingUtilities.invokeLater(() -> {
            new SimpleGUI().setVisible(true);
        });
    }
}